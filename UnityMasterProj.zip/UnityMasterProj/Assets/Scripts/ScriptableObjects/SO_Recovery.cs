﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Recovery", menuName = "Scriptable Objects/Abilities/Recovery Move")]
public class SO_Recovery : ABS_Abilities
{
    public override void UseAbility(string triggerName, Animator _anim)
    {
        
    }
}
