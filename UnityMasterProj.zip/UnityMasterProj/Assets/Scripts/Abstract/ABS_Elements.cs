﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ABS_Elements : ScriptableObject
{
	public enum elementType
	{
		EARTH,
		FIRE,
		WATER,
		AIR,
		LIGHTNING
	}
}
