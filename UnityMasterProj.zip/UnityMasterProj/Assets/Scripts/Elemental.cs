﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elemental  {
	public  enum elementType {Neutral,Fire,Water,Wind,Lightning,Earth};
}